/**
 * 
 */
package coviddatafetch;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * @author Suhua Qin
 *
 */

public class CovidDataFetch {

	public static String baseEndPoint = "https://api.covid19api.com/country/";
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException, InterruptedException{

		// TODO Auto-generated method stub
		System.out.println("Welcome to covid data fetching program.");

		ArrayList<String> time = new ArrayList<String>();
		ArrayList<String> countries = new ArrayList<String>();
		
		// read command line input
		readParams(args, time, countries);
		
		// open file and write titles
		String[] headers = {"Country", "Confirmed", "Deaths", "Recovered", "Active"};
		PrintWriter writer = createCSV("covid_data.csv", headers);
		
		// pull and save covid data from endpoint
		for (String c : countries) {
			String endpoint = baseEndPoint + c +"?from=" + time.get(0) + "&to=" + time.get(1);
			List<LinkedHashMap<String, Object>> data = get(endpoint, c);
			if (data != null) {
				saveToCSV(data, writer, c);
			}
		}
		
		writer.close();
	}
	
	/**
	 * @param name			csv name
	 * @param headers		sheet columns
	 * @return
	 * @throws IOException
	 */
	public static PrintWriter createCSV(String name, String[] headers) throws IOException {
		PrintWriter writer = new PrintWriter(new File(name));
		StringBuilder sb = new StringBuilder();
		for (String h : headers) {
			sb.append(h + ",");
		}
		sb.append('\n');
		writer.write(sb.toString());
		return writer;
	}
	
	/**
	 * @param uri					endpoint
	 * @param country				country name
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public static List<LinkedHashMap<String, Object>> get(String uri, String country) throws IOException, InterruptedException {
	    HttpClient client = HttpClient.newHttpClient();
	    HttpRequest request = HttpRequest.newBuilder(URI.create(uri)).header("accept", "application/json").build();
	    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
	    String res = response.body().toString();
	    	    
	    ObjectMapper mapper = new ObjectMapper();
	    List<LinkedHashMap<String, Object>> data = null;
	    
	    try {
	    	data = mapper.readValue(res, ArrayList.class);
	    }catch(IOException e) {
	    	System.out.println( country + ": failed! "
					+ "Please ensure your country name is correct");
	    }
	    
	    return data;
	}
	
	/**
	 * @param data			data fetched from endpoint
	 * @param writer		writer object
	 * @param country		country name
	 * @throws IOException
	 */
	public static void saveToCSV(List<LinkedHashMap<String, Object>> data, PrintWriter writer, String country) throws IOException {

		StringBuilder sb = new StringBuilder();
		try {
			for (LinkedHashMap<String, Object> c : data) {
				
		            sb = new StringBuilder();
					sb.append(c.get("Date"));
					sb.append(",");
					sb.append(c.get("Country"));
					sb.append(",");
					sb.append(c.get("Confirmed").toString());
					sb.append(",");
					sb.append(c.get("Deaths").toString());
					sb.append(",");
					sb.append(c.get("Recovered").toString());
					sb.append(",");
					sb.append(c.get("Active").toString());
					sb.append('\n');
					writer.write(sb.toString());
	        }
			System.out.println( country + ": success!");
		}
		catch (Exception e) {
			System.out.println( country + ": failed!"
					+ "Please ensure your country name is correct");
		}
	}
	
	/**
	 * @param args		command line arugments
	 * @param time		dates from command line
	 * @param countries	countries from command line
	 */
	public static void readParams(String[] args, ArrayList<String> time, ArrayList<String> countries) {
		int i = 0;
		while (i < args.length) {
			if (args[i].equals("-time")) {				
				if (++i < args.length && args[i] != null && dateValidate(args[i])) {
					time.add(args[i]);
				}

				if (++i < args.length && args[i] != null && dateValidate(args[i])) {
					time.add(args[i]);
					
				}
	        }
			
			else if (args[i].equals("-country")) {
				if (++i < args.length && args[i] != null) {
					countries.add(args[i].replace("_", "%20"));
				}
				if (++i < args.length && args[i] != null) {
					countries.add(args[i].replace("_", "%20"));
				}
				if (++i < args.length && args[i] != null) {
					countries.add(args[i].replace("_", "%20"));
				}
				if (++i < args.length && args[i] != null) {
					countries.add(args[i].replace("_", "%20"));
				}
				
			}
			else {
				i++;
			}
		}
		// default dates
		if (time.size() != 2) {
			System.out.println("No valid date range found. Using defualt range.");
			time.clear();
			time.add(LocalDateTime.now().toString());
			time.add(LocalDateTime.now().minusDays(7).toString());
		}
		// default countries
		if (countries.size() == 0) {
			System.out.println("No valid countries found. Using defualt countries.");
			countries.clear();
			countries.add("Canada");
			countries.add("South%20Africa");
		}
	}
	
	/**
	 * @param s	date in string format
	 * @return
	 */
	public static boolean dateValidate(String s) {
		boolean valid = true;
		try {
			Date date = new SimpleDateFormat("yyyy-mm-dd").parse(s); 
		}
		catch (Exception e) {
			valid = false;
		}
		return valid;
	}

}

